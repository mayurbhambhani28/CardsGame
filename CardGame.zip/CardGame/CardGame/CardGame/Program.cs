﻿using System;
using System.Collections.Generic;

namespace CardsGame
{
    public class Program
    {
        static List<string> Player1 = new List<string>();
        static List<string> Player2 = new List<string>();
        static List<string> Player3 = new List<string>();
        static List<string> Player4 = new List<string>();

        static List<string> DiscardPlayer1 = new List<string>();
        static List<string> DiscardPlayer2 = new List<string>();
        static List<string> DiscardPlayer3 = new List<string>();
        static List<string> DiscardPlayer4 = new List<string>();

        static List<string> HoldCards = new List<string>();
        static int noOfPlayers = 2;
        static int player1lost = 0;
        static int player2lost = 0;
        static int player3lost = 0;
        static int player4lost = 0;

        public static void Main()
        {
            StartPlaying();
           
            Console.ReadLine();
            Environment.Exit(0);
        }

        public static void StartPlaying()
        {
            bool play = true;
           

            while (play)
            {
                noOfPlayers = HowManyPlayers();

                //deck full of 40 cards. Here c stands for clubs,s stands for spades, h stands for heart and d stands for diamond
                string[] cards = { "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9", "s10", "h1", "h2", "h3", "h4", "h5", "h6", "h7", "h8", "h9", "h10", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10" };
                int n = cards.Length;
                int start = shuffle(cards, n, noOfPlayers, Player1, Player2);

                if (start > 0)
                {
                    int result = StartGame(Player1, Player2);


                    if (result > 0 && noOfPlayers == 2)
                    {
                        if ((Player1.Count + DiscardPlayer1.Count) > (Player2.Count + DiscardPlayer2.Count))
                        {
                            Console.WriteLine("Player 1 wins the game");
                        }
                        else if ((Player1.Count + DiscardPlayer1.Count) < (Player2.Count + DiscardPlayer2.Count))
                        {
                            Console.WriteLine("Player 2 wins the game");
                        }
                    }
                    else if (result > 0 && noOfPlayers == 3)
                    {
                        if (player1lost == 0)
                        {
                            Console.WriteLine("Player 1 wins the game");
                        }
                        if (player2lost == 0)
                        {
                            Console.WriteLine("Player 2 wins the game");
                        }
                        if (player3lost == 0)
                        {
                            Console.WriteLine("Player 3 wins the game");
                        }
                    }
                    else if (result > 0 && noOfPlayers == 4)
                    {
                        if (player1lost == 0)
                        {
                            Console.WriteLine("Player 1 wins the game");
                        }
                        if (player2lost == 0)
                        {
                            Console.WriteLine("Player 2 wins the game");
                        }
                        if (player3lost == 0)
                        {
                            Console.WriteLine("Player 3 wins the game");
                        }
                        if (player4lost == 0)
                        {
                            Console.WriteLine("Player 4 wins the game");
                        }
                    }

                    play = ContinuePlaying();
                    
                    if (play)
                    {
                        ResetAll();
                    }
                }
            }
        }
       public static int shuffle(string[] cards, int n, int noOfPlayers,List<string> Player1, List<string> Player2)
        {
            try
            {
                Random r = new Random();

                //shuffling starts
                for (int i = n - 1; i > -1; i--)
                {

                    int j = r.Next(0, i + 1);

                    string temp = cards[i];
                    cards[i] = cards[j];
                    cards[j] = temp;
                }

                if (noOfPlayers == 2)
                {
                    //after shuffling gets over then one by one card is assigned to player1 and player2 alternatively
                    for (int i = 0; i < n; i++)
                    {
                        if (i % 2 == 0)
                        {
                            Player1.Add(cards[i]);
                        }
                        else
                        {
                            Player2.Add(cards[i]);
                        }
                    }
                }
                else if (noOfPlayers == 3)
                {
                    //after shuffling gets over then one by one card is assigned to player1,player2 and player 3 alternatively
                    for (int i = 0; i < n-1; i++)
                    {
                        if (i % 3 == 0)
                        {
                            Player1.Add(cards[i]);
                        }
                        else if (i % 3 == 1)
                        {
                            Player2.Add(cards[i]);
                        }
                        else if (i % 3 == 2)
                        {
                            Player3.Add(cards[i]);
                        }
                    }
                }
                else if (noOfPlayers == 4)
                {
                    //after shuffling gets over then one by one card is assigned to player1,player2,player 3 and player4 alternatively
                    for (int i = 0; i < n; i++)
                    {
                        if (i % 4 == 0)
                        {
                            Player1.Add(cards[i]);
                        }
                        else if(i % 4 == 1)
                        {
                            Player2.Add(cards[i]);
                        }
                        else if (i % 4 == 2)
                        {
                            Player3.Add(cards[i]);
                        }
                        else if (i % 4 == 3)
                        {
                            Player4.Add(cards[i]);
                        }
                    }
                }
                return 1;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return 0;
            }
        }
        public static int StartGame(List<string> Player1, List<string> Player2)
        {
            try
            {                
                while (true)
                {
                    string temp1 = "0", temp2 = "0", temp3 = "0", temp4 = "0";
                    int p1 = 0;int p2 = 0; int p3 = 0; int p4 = 0;

                    if (player1lost == 0)
                    {
                        p1 = Player1Chance(Player1);

                        //removing first character and then judging on numeric value coming after...values are s1,h1,d1,c1 where s stands spade,h stands for heart, d stands for diamond and c stands for club
                        temp1 = Player1[p1].Substring(1);
                    }

                    if (player2lost == 0)
                    {
                        p2 = Player2Chance(Player2);
                        temp2 = Player2[p2].Substring(1);
                    }

                    if (noOfPlayers == 3 && player3lost==0)
                    {
                        p3 = Player3Chance(Player3);
                        temp3 = Player3[p3].Substring(1);

                    }
                    else if (noOfPlayers == 4)
                    {
                        if (player3lost == 0)
                        {
                            p3 = Player3Chance(Player3);
                            temp3 = Player3[p3].Substring(1);
                        }

                        if (player4lost == 0)
                        {
                            p4 = Player4Chance(Player4);
                            temp4 = Player4[p4].Substring(1);
                        }
                    }

                    int[] arrNum=new int[4];

                    if (noOfPlayers == 2)
                    {
                        arrNum[0] = Convert.ToInt32(temp1);
                        arrNum[1] = Convert.ToInt32(temp2);
                    }
                    else if (noOfPlayers == 3)
                    {
                        arrNum[0] = Convert.ToInt32(temp1);
                        arrNum[1] = Convert.ToInt32(temp2);
                        arrNum[2] = Convert.ToInt32(temp3);
                    }
                    else if (noOfPlayers == 4)
                    {
                        arrNum[0] = Convert.ToInt32(temp1);
                        arrNum[1] = Convert.ToInt32(temp2);
                        arrNum[2] = Convert.ToInt32(temp3);
                        arrNum[3] = Convert.ToInt32(temp4);
                    }

                    if (noOfPlayers > 2)
                    {
                        int max = 0;
                        for (int k = 0; k < arrNum.Length; k++)
                        {
                            if (arrNum[k] > max)
                            {
                                max = arrNum[k];
                            }
                        }
                        if (max == Convert.ToInt32(temp1))
                        {
                            Console.WriteLine("\n Player 1 wins this round \n");
                            if(player1lost==0)
                            DiscardPlayer1.Add(Player1[p1]);
                            
                            if(player2lost==0)
                            DiscardPlayer1.Add(Player2[p2]);

                            if(player3lost==0)
                            DiscardPlayer1.Add(Player3[p3]);

                            if (noOfPlayers == 4 && player4lost==0)
                                DiscardPlayer1.Add(Player4[p4]);
                        }
                        else if (max == Convert.ToInt32(temp2))
                        {
                            Console.WriteLine("\n Player 2 wins this round \n");
                            if (player1lost == 0)
                                DiscardPlayer2.Add(Player1[p1]);

                            if (player2lost == 0)
                                DiscardPlayer2.Add(Player2[p2]);

                            if (player3lost == 0)
                                DiscardPlayer2.Add(Player3[p3]);

                            if(noOfPlayers==4 && player4lost==0)
                            DiscardPlayer2.Add(Player4[p4]);
                        }
                        else if (max == Convert.ToInt32(temp3))
                        {
                            Console.WriteLine("\n Player 3 wins this round \n");

                            if (player1lost == 0)
                                DiscardPlayer3.Add(Player1[p1]);

                            if (player2lost == 0)
                                DiscardPlayer3.Add(Player2[p2]);

                            if (player3lost == 0)
                                DiscardPlayer3.Add(Player3[p3]);

                            if (noOfPlayers == 4 && player4lost==0)
                                DiscardPlayer3.Add(Player4[p4]);
                        }
                        else if (max == Convert.ToInt32(temp4) && noOfPlayers==4)
                        {
                            Console.WriteLine("\n Player 4 wins this round \n");

                            if (player1lost == 0)
                                DiscardPlayer4.Add(Player1[p1]);

                            if (player2lost == 0)
                                DiscardPlayer4.Add(Player2[p2]);

                            if (player3lost == 0)
                                DiscardPlayer4.Add(Player3[p3]);

                            if (player4lost == 0)
                                DiscardPlayer4.Add(Player4[p4]);
                        }

                        if (player1lost == 0)
                            Player1.Remove(Player1[p1]);

                        if (player2lost == 0)
                            Player2.Remove(Player2[p2]);

                        if (noOfPlayers == 3)
                        {
                            if (player3lost == 0)
                                Player3.Remove(Player3[p3]);
                        }
                        if (noOfPlayers == 4)
                        {
                            if (player3lost == 0)
                                Player3.Remove(Player3[p3]);

                            if (player4lost == 0)
                                Player4.Remove(Player4[p4]);
                        }


                        if (Player1.Count == 0 && DiscardPlayer1.Count > 0)
                        {
                            Player1 = DiscardPlayer1;
                        }
                        if (Player2.Count == 0 && DiscardPlayer2.Count > 0)
                        {
                            Player2 = DiscardPlayer2;
                        }
                        if (Player3.Count == 0 && DiscardPlayer3.Count > 0)
                        {
                            Player3 = DiscardPlayer3;
                        }
                        if (Player4.Count == 0 && DiscardPlayer4.Count > 0)
                        {
                            Player4 = DiscardPlayer4;
                        }

                        if (Player1.Count == 0 && DiscardPlayer1.Count == 0)
                        {
                            player1lost=1;
                        }
                        if (Player2.Count == 0 && DiscardPlayer2.Count == 0)
                        {
                            player2lost = 1;
                        }
                        if (noOfPlayers==3 && Player3.Count == 0 && DiscardPlayer3.Count == 0)
                        {
                            player3lost = 1;
                        }
                        if (noOfPlayers == 4 && Player4.Count == 0 && DiscardPlayer4.Count == 0)
                        {
                            if (Player3.Count == 0 && DiscardPlayer3.Count == 0)
                            {
                                player3lost = 1;
                            }

                            player4lost = 1;
                        }

                        if (noOfPlayers == 3 && ((player1lost + player2lost + player3lost) == 2))
                        {
                            return 1;
                        }
                        if (noOfPlayers == 4 && ((player1lost + player2lost + player3lost + player4lost) == 3))
                        {
                            return 1;
                        }
                    }

                    else if (noOfPlayers == 2)
                    {
                        if (Convert.ToInt32(temp1) > Convert.ToInt32(temp2))
                        {
                            Console.WriteLine("\n Player 1 wins this round \n");
                            DiscardPlayer1.Add(Player2[p2]);
                            DiscardPlayer1.Add(Player1[p1]);

                            if (HoldCards.Count > 0)
                            {
                                DiscardPlayer1.AddRange(HoldCards);
                                HoldCards.Clear();
                            }
                        }
                        else if (Convert.ToInt32(temp1) < Convert.ToInt32(temp2))
                        {
                            Console.WriteLine("\n Player 2 wins this round \n");
                            DiscardPlayer2.Add(Player2[p2]);
                            DiscardPlayer2.Add(Player1[p1]);

                            if (HoldCards.Count > 0)
                            {
                                DiscardPlayer2.AddRange(HoldCards);
                                HoldCards.Clear();
                            }
                        }
                        else
                        {
                            HoldCards.Add(Player1[p1]);
                            HoldCards.Add(Player2[p2]);
                            Console.WriteLine("\n No winner in this round \n");
                        }
                        Player1.Remove(Player1[p1]);
                        Player2.Remove(Player2[p2]);                     

                        if (Player1.Count == 0 && DiscardPlayer1.Count > 0)
                        {
                            Player1 = DiscardPlayer1;
                        }
                        if (Player2.Count == 0 && DiscardPlayer2.Count > 0)
                        {
                            Player2 = DiscardPlayer2;
                        }

                        if (Player1.Count == 0 && DiscardPlayer1.Count == 0)
                        {
                            break;
                        }
                        else if (Player2.Count == 0 && DiscardPlayer2.Count == 0)
                        {
                            break;
                        }
                    }

                    
                }//end while
                return 1;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return 0;
            }
           
        }

        public static int Player1Chance(List<string> Player1)
        {
            Random r = new Random();
            int num = r.Next(0, Player1.Count);

            Console.WriteLine("Player 1 (" + Player1.Count.ToString() + " cards) " + Player1[num]);

            return num;
        }
        public static int Player2Chance(List<string> Player2)
        {
            Random r = new Random();
            int num = r.Next(0, Player2.Count);

            Console.WriteLine("Player 2 (" + Player2.Count.ToString() + " cards) " + Player2[num]);

            return num;
        }
        public static int Player3Chance(List<string> Player3)
        {
            Random r = new Random();
            int num = r.Next(0, Player3.Count);

            Console.WriteLine("Player 3 (" + Player3.Count.ToString() + " cards) " + Player3[num]);

            return num;
        }
        public static int Player4Chance(List<string> Player4)
        {
            Random r = new Random();
            int num = r.Next(0, Player4.Count);

            Console.WriteLine("Player 4 (" + Player4.Count.ToString() + " cards) " + Player4[num]);

            return num;
        }
        public static bool ContinuePlaying()
        {
            bool play;

            Console.WriteLine("\n  Do you want to play again? Press 'y' for yes and 'n' for no:");

            string response = Console.ReadLine();

            switch (response.ToLower())
            {
                case "y":
                    play = true;
                    break;
                case "n":
                    play = false;
                    break;
                default:
                    play = false;
                    break;
            }
            return play;
        }

        public static int HowManyPlayers()
        {
            int num; 

            Console.WriteLine("\n  How many players want to play?(minimum 2 and maximum 4)");

            string response = Console.ReadLine();

            switch (response)
            {
                case "2":
                    num = 2;
                    break;
                case "3":
                    num = 3;
                    break;
                case "4":
                    num = 4;
                    break;
                default:
                    num=2;
                    break;
            }
            return num;
        }

        public static void ResetAll()
        {
            Player1.Clear();
            Player1 = new List<string>();

            Player2.Clear();
            Player2 = new List<string>();

            Player3.Clear();
            Player3 = new List<string>();

            Player4.Clear();
            Player4 = new List<string>();

            DiscardPlayer1.Clear();
            DiscardPlayer1 = new List<string>();

            DiscardPlayer2.Clear();
            DiscardPlayer2 = new List<string>();

            DiscardPlayer3.Clear();
            DiscardPlayer3 = new List<string>();

            DiscardPlayer4.Clear();
            DiscardPlayer4 = new List<string>();

            HoldCards.Clear();
            HoldCards = new List<string>();

            noOfPlayers = 2;
            player1lost = 0;
            player2lost = 0;
            player3lost = 0;
            player4lost = 0;
        }
    }
}

