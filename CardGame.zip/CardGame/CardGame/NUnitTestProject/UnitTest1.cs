using NUnit.Framework;
using CardsGame;
using System.IO;
using System;
using System.Collections.Generic;

namespace NUnitTestProject
{
    public class Tests
    {
        
        [SetUp]
        public void Setup()
        {
            
        }

        [Test]
        public void Test_ContinuePlaying_Positive()
        {
            var input = new StringReader("y");
            Console.SetIn(input);

            bool result = Program.ContinuePlaying();

            Assert.AreEqual(result,true);
        }

        [Test]
        public void Test_ContinuePlaying_Negative()
        {
            var input = new StringReader("n");
            Console.SetIn(input);

            bool result = Program.ContinuePlaying();

            Assert.AreEqual(result, false);
        }

        [Test]
        public void Test_ContinuePlaying_WrongResponse()
        {
            var input = new StringReader("s");
            Console.SetIn(input);

            bool result = Program.ContinuePlaying();

            Assert.AreEqual(result, false);
        }
        [Test]
        public void Test_HowManyPlayers()
        {
            var input = new StringReader("2");
            Console.SetIn(input);

            int result = Program.HowManyPlayers();

            Assert.AreEqual(result, 2);
        }

        [Test]
        public void Test_Player1Chance()
        {
            List<string> Player1 = new List<string>();

            Player1.Add("s1");
            Player1.Add("s2");
            Player1.Add("s2");

            var output = new StringWriter();
            Console.SetOut(output);

            int result = Program.Player1Chance(Player1);

            Assert.IsTrue(result>-1);
        }

        [Test]
        public void Test_Player2Chance()
        {
            List<string> Player2 = new List<string>();

            Player2.Add("s1");
            Player2.Add("s2");
            Player2.Add("s2");

            var output = new StringWriter();
            Console.SetOut(output);

            int result = Program.Player2Chance(Player2);

            Assert.IsTrue(result > -1);
        }

        [Test]
        public void Test_Player3Chance()
        {
            List<string> Player3 = new List<string>();

            Player3.Add("s1");
            Player3.Add("s2");
            Player3.Add("s2");

            var output = new StringWriter();
            Console.SetOut(output);

            int result = Program.Player3Chance(Player3);

            Assert.IsTrue(result > -1);
        }

        [Test]
        public void Test_Player4Chance()
        {
            List<string> Player4 = new List<string>();

            Player4.Add("s1");
            Player4.Add("s2");
            Player4.Add("s2");

            var output = new StringWriter();
            Console.SetOut(output);

            int result = Program.Player4Chance(Player4);

            Assert.IsTrue(result > -1);
        }
        [Test]
        public void Shuffle_PositiveScenario()
        {
            List<string> Player1 = new List<string>();
            List<string> Player2 = new List<string>();

            string[] cards = { "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9", "s10", "h1", "h2", "h3", "h4", "h5", "h6", "h7", "h8", "h9", "h10", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10" };
            int n = cards.Length;
            int start = Program.shuffle(cards, n,2, Player1, Player2);

            Assert.IsTrue(start > 0);

        }

        [Test]
        public void Shuffle_NegativeScenario()
        {
            List<string> Player1 = new List<string>();
            List<string> Player2 = new List<string>();

            string[] cards = { "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9", "s10", "h1", "h2", "h3", "h4", "h5", "h6", "h7", "h8", "h9", "h10", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10" };
            int n = 100;
            int start = Program.shuffle(cards, n, 2,Player1, Player2);

            Assert.AreEqual(start,0);
        }


        [Test]
        public void StartGame_PositiveScenario()
        {
            List<string> Player1 = new List<string>();

            Player1.Add("d2");
            Player1.Add("d4");
            Player1.Add("d5");            
            Player1.Add("d6");

            List<string> Player2 = new List<string>();

            Player2.Add("s2");
            Player2.Add("s1");
            Player2.Add("s7");            
            Player2.Add("s3");

            var output = new StringWriter();
            Console.SetOut(output);

                     
            int start = Program.StartGame(Player1, Player2);

            Assert.IsTrue(start>0);
        }

        [Test]
        public void StartGame_NegativeScenario()
        {
            List<string> Player1 = new List<string>();

            Player1.Add("d4");
            Player1.Add("d5");
            Player1.Add("d6");

            List<string> Player2 = new List<string>();

            Player2.Add("s1");
            Player2.Add("s2");
            Player2.Add("s3");

            var output = new StringWriter();
            Console.SetOut(output);

                      
            int start = Program.StartGame(Player1, Player2);

            Assert.AreEqual(start,0);
        }
        [Test]
        public void StartPlaying()
        {
            var input = new StringReader("n");
            Console.SetIn(input);

            Program.StartPlaying();
            Assert.IsTrue(true);
        }
    }
}