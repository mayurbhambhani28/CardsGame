﻿using System;
using System.Collections.Generic;

namespace CardsGame
{
    public class Program
    {        
        public static void Main()
        {
            StartPlaying();
           
            Console.ReadLine();
            Environment.Exit(0);
        }

        public static void StartPlaying()
        {
            bool play = true;

            while (play)
            {
                List<string> Player1 = new List<string>();
                List<string> Player2 = new List<string>();

                //deck full of 40 cards. Here c stands for clubs,s stands for spades, h stands for heart and d stands for diamond
                string[] cards = { "c1", "c2", "c3", "c4", "c5", "c6", "c7", "c8", "c9", "c10", "s1", "s2", "s3", "s4", "s5", "s6", "s7", "s8", "s9", "s10", "h1", "h2", "h3", "h4", "h5", "h6", "h7", "h8", "h9", "h10", "d1", "d2", "d3", "d4", "d5", "d6", "d7", "d8", "d9", "d10" };
                int n = cards.Length;
                int start = shuffle(cards, n, Player1, Player2);

                if (start > 0)
                {
                    int result = StartGame(n / 2, Player1, Player2);
                    if (result > 0)
                    {
                        if (Player1.Count > Player2.Count)
                        {
                            Console.WriteLine("Player 1 wins the game");
                        }

                        else if (Player1.Count < Player2.Count)
                        {
                            Console.WriteLine("Player 2 wins the game");
                        }
                    }

                    play = ContinuePlaying();
                }
            }
        }
       public static int shuffle(string[] cards, int n, List<string> Player1, List<string> Player2)
        {
            try
            {
                Random r = new Random();

                //shuffling starts
                for (int i = n - 1; i > -1; i--)
                {

                    int j = r.Next(0, i + 1);

                    string temp = cards[i];
                    cards[i] = cards[j];
                    cards[j] = temp;
                }

                //after shuffling gets over then one by one card is assigned to player1 and player2 alternatively
                for (int i = 0; i < n; i++)
                {
                    if (i % 2 == 0)
                    {
                        Player1.Add(cards[i]);
                    }
                    else
                    {
                        Player2.Add(cards[i]);
                    }
                }
                return 1;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return 0;
            }
        }
        public static int StartGame(int n, List<string> Player1, List<string> Player2)
        {
            try
            {
                for (int i = 0; i < n; i++)
                {
                    int p1 = Player1Chance(Player1);

                    //removing first character and then judging on numeric value coming after...values are s1,h1,d1,c1 where s stands spade,h stands for heart, d stands for diamond and c stands for club
                    string temp1 = Player1[p1].Substring(1);

                    int p2 = Player2Chance(Player2);
                    string temp2 = Player2[p2].Substring(1);

                    if (Convert.ToInt32(temp1) > Convert.ToInt32(temp2))
                    {
                        Console.WriteLine("\n Player 1 wins this round \n");
                        Player1.Add(Player2[p2]);
                        Player2.Remove(Player2[p2]);
                    }
                    else if (Convert.ToInt32(temp1) < Convert.ToInt32(temp2))
                    {
                        Console.WriteLine("\n Player 2 wins this round \n");
                        Player2.Add(Player1[p1]);
                        Player1.Remove(Player1[p1]);
                    }
                    else
                    {
                        Console.WriteLine("\n No winner in this round \n");
                    }
                }
                return 1;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return 0;
            }
        }

        public static int Player1Chance(List<string> Player1)
        {
            Random r = new Random();
            int num = r.Next(0, Player1.Count);

            Console.WriteLine("Player 1 (" + Player1.Count.ToString() + ") " + Player1[num]);

            return num;
        }
        public static int Player2Chance(List<string> Player2)
        {
            Random r = new Random();
            int num = r.Next(0, Player2.Count);

            Console.WriteLine("Player 2 (" + Player2.Count.ToString() + ") " + Player2[num]);

            return num;
        }
        public static bool ContinuePlaying()
        {
            bool play;

            Console.WriteLine("\n  Do you want to play again? Press 'y' for yes and 'n' for no:");

            string response = Console.ReadLine();

            switch (response.ToLower())
            {
                case "y":
                    play = true;
                    break;
                case "n":
                    play = false;
                    break;
                default:
                    play = false;
                    break;
            }
            return play;
        }
    }
}

